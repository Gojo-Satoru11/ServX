"""
WSGI entry point for production deployment
Used by Gunicorn, uWSGI, etc.
"""

from app_production import create_app
import os

# Load environment variables from .env file
from dotenv import load_dotenv
load_dotenv()

# Create application instance
app = create_app()

if __name__ == "__main__":
    app.run()
