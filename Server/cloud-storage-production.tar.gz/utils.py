"""
Utility functions for cloud storage
"""

import hashlib
import secrets
import os
from werkzeug.utils import secure_filename

# Allowed file extensions
ALLOWED_EXTENSIONS = {
    'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx',
    'xls', 'xlsx', 'ppt', 'pptx', 'zip', 'rar', 'mp3', 'mp4',
    'avi', 'mov', 'csv', 'json', 'xml', 'py', 'js', 'html',
    'css', 'md', 'tar', 'gz', 'bmp', 'svg', 'webp', 'ogg',
    'wav', 'flac', 'mkv', 'webm', '7z', 'iso'
}

def hash_password(password, salt=None):
    """Hash password with PBKDF2"""
    if salt is None:
        salt = secrets.token_hex(16)
    
    hashed = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        100000  # iterations
    )
    return salt, hashed.hex()

def verify_password(stored_salt, stored_hash, provided_password):
    """Verify password against stored hash"""
    _, new_hash = hash_password(provided_password, stored_salt)
    return new_hash == stored_hash

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def format_file_size(size_bytes):
    """Convert bytes to human readable format"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} PB"

def get_file_type_icon(extension):
    """Get emoji icon for file type"""
    icons = {
        'jpg': '🖼️', 'jpeg': '🖼️', 'png': '🖼️', 'gif': '🖼️', 'webp': '🖼️',
        'pdf': '📄',
        'doc': '📝', 'docx': '📝',
        'xls': '📊', 'xlsx': '📊',
        'ppt': '📽️', 'pptx': '📽️',
        'zip': '📦', 'rar': '📦', 'tar': '📦', 'gz': '📦', '7z': '📦',
        'mp3': '🎵', 'wav': '🎵', 'ogg': '🎵', 'flac': '🎵',
        'mp4': '🎬', 'avi': '🎬', 'mov': '🎬', 'mkv': '🎬', 'webm': '🎬',
        'py': '💻', 'js': '💻', 'html': '💻', 'css': '💻', 'json': '💻'
    }
    return icons.get(extension.lower(), '📄')

def get_directory_size(path):
    """Calculate total size of directory"""
    total_size = 0
    try:
        for dirpath, dirnames, filenames in os.walk(path):
            for filename in filenames:
                filepath = os.path.join(dirpath, filename)
                if os.path.exists(filepath):
                    total_size += os.path.getsize(filepath)
    except (OSError, PermissionError):
        pass
    return total_size

def get_files_in_directory(directory_path):
    """Get list of files with metadata"""
    from datetime import datetime
    
    files = []
    try:
        for filename in os.listdir(directory_path):
            filepath = os.path.join(directory_path, filename)
            if os.path.isfile(filepath):
                stat = os.stat(filepath)
                extension = filename.rsplit('.', 1)[1].lower() if '.' in filename else 'file'
                
                files.append({
                    'name': filename,
                    'size': stat.st_size,
                    'size_formatted': format_file_size(stat.st_size),
                    'uploaded': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M'),
                    'type': extension,
                    'icon': get_file_type_icon(extension)
                })
        
        files.sort(key=lambda x: x['uploaded'], reverse=True)
    except (OSError, PermissionError):
        pass
    
    return files

def safe_filename(filename, counter=None):
    """Generate safe filename, handling duplicates"""
    secure_name = secure_filename(filename)
    
    if counter is not None:
        base_name, extension = os.path.splitext(secure_name)
        secure_name = f"{base_name}_{counter}{extension}"
    
    return secure_name

def ensure_directory_exists(directory_path):
    """Ensure directory exists, create if not"""
    os.makedirs(directory_path, exist_ok=True)
    return directory_path
